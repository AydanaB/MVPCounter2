package com.example.mvpcounter;

public class PresenterContracts {

    interface CounterView{
        void updateCounter(int counter);
        void showToast(int counter);
        void changeTvColor(int counter);
    }

    interface CounterPresenter{
        void increment();
        void decrement();
        void attachView(CounterView counterView);
    }
}
